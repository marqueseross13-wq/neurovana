<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
  http_response_code(200);
  echo json_encode(["ok" => true]);
  exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  http_response_code(405);
  echo json_encode(["error" => "Use POST"]);
  exit;
}

// ✅ Put your OpenAI key here (server-side only)
$OPENAI_API_KEY = "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";

$raw = file_get_contents("php://input");
$body = json_decode($raw, true);

if (!isset($body["messages"]) || !is_array($body["messages"])) {
  http_response_code(400);
  echo json_encode(["error" => "messages must be an array"]);
  exit;
}

$payload = [
  "model" => "gpt-4.1-mini",
  "messages" => $body["messages"],
  "temperature" => 0.7
];

$ch = curl_init("https://api.openai.com/v1/chat/completions");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Content-Type: application/json",
  "Authorization: Bearer " . $OPENAI_API_KEY
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

$result = curl_exec($ch);
$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($result === false) {
  http_response_code(500);
  echo json_encode(["error" => "cURL error: " . curl_error($ch)]);
  curl_close($ch);
  exit;
}

curl_close($ch);

$data = json_decode($result, true);

if ($http < 200 || $http >= 300) {
  $msg = $data["error"]["message"] ?? "OpenAI error";
  http_response_code($http);
  echo json_encode(["error" => $msg, "raw" => $data]);
  exit;
}

$reply = $data["choices"][0]["message"]["content"] ?? "";
echo json_encode(["reply" => $reply]);
